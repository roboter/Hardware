/*!
 * @file        ubsd_descriptor.h
 *
 * @brief       HID descriptor head file
 *
 * @version     V1.0.1
 *
 * @date        2022-09-20
 *
 * @attention
 *
 *  Copyright (C) 2020-2022 Geehy Semiconductor
 *
 *  You may not use this file except in compliance with the
 *  GEEHY COPYRIGHT NOTICE (GEEHY SOFTWARE PACKAGE LICENSE).
 *
 *  The program is only for reference, which is distributed in the hope
 *  that it will be useful and instructional for customers to develop
 *  their software. Unless required by applicable law or agreed to in
 *  writing, the program is distributed on an "AS IS" BASIS, WITHOUT
 *  ANY WARRANTY OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the GEEHY SOFTWARE PACKAGE LICENSE for the governing permissions
 *  and limitations under the License.
 */

/* Define to prevent recursive inclusion */
#ifndef __USBD_DESCRIPTOR_H
#define __USBD_DESCRIPTOR_H

/* Includes */
#include "usbd_core.h"

/** @addtogroup Examples
  @{
  */

/** @addtogroup USB_HID_Mouse
  @{
  */

/** @defgroup USB_HID_Mouse_Macros Macros
  @{
*/

/** @defgroup USBD_Descriptor_Macros
  @{
*/

#define HID_MOUSE_DEVICE_DESCRIPTOR_SIZE        (18)
#define HID_MOUSE_CONFIG_DESCRIPTOR_SIZE        (34)
#define HID_MOUSE_LANGID_STRING_SIZE            (4)
#define HID_MOUSE_VENDOR_STRING_SIZE            (16)
#define HID_MOUSE_PRODUCT_STRING_SIZE           (32)
#define HID_MOUSE_REPORT_DESCRIPTOR_SIZE        (74)
#define HID_MOUSE_SERIAL_STRING_SIZE            (12)
#define SRTING_DESC_NUM                         (4)

/**@} end of group USBD_Descriptor_Macros */
/**@} end of group USB_HID_Mouse_Macros */

/** @defgroup USB_HID_Mouse_Enumerations Enumerations
  @{
*/

/**@} end of group USB_HID_Mouse_Enumerations */

/** @defgroup USB_HID_Mouse_Structures Structures
  @{
*/

/**@} end of group USB_HID_Mouse_Structures */

/** @defgroup USB_HID_Mouse_Variables Variables
  @{
*/

/** @defgroup USBD_Descriptor_Variables
  @{
*/

extern USBD_Descriptor_T g_deviceDescriptor;
extern USBD_Descriptor_T g_configDescriptor;
extern USBD_Descriptor_T g_stringDescriptor[SRTING_DESC_NUM];
extern USBD_Descriptor_T g_ReportDescriptor;

/**@} end of group USBD_Descriptor_Variables */
/**@} end of group USB_HID_Mouse_Variables */

/** @defgroup USB_HID_Mouse_Functions Functions
  @{
  */

#endif /*__USBD_DESCRIPTOR_H */

/**@} end of group USB_HID_Mouse_Functions */
/**@} end of group USB_HID_Mouse */
/**@} end of group Examples */
