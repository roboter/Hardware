ORIGINAL CONFIG FILES
=====================
In this '.config_orig' folder, Embeetle stores all the initial config files.
They are used for three-way merges.