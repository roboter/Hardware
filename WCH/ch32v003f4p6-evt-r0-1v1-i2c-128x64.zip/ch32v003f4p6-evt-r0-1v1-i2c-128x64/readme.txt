Converter:
https://bitluni.net/wp-content/uploads/2018/02/Image2Header.html


https://javl.github.io/image2cpp/
