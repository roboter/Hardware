

void USART_Init(unsigned int baudrate);

void Usart_Tx(char);
char Usart_Rx(void);
