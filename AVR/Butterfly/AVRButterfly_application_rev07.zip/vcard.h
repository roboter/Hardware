char RS232(char input);
char vCard(char input);
char EnterName(char input);

#define STRLENGHT    25
