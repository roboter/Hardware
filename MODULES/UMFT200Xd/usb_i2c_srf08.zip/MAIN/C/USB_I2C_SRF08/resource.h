//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by USB_I2C_SRF08.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_USB_I2C_SRF08_DIALOG        102
#define IDD_USB_I2C_SRFxx_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_COM1                        1001
#define IDC_COM2                        1002
#define IDC_COM3                        1003
#define IDC_COM4                        1004
#define IDC_COM5                        1005
#define IDC_COM6                        1006
#define IDC_COM7                        1007
#define IDC_COM8                        1008
#define IDC_SRF08_INCH                  1010
#define IDC_SRF08_US                    1011
#define IDC_SRF08_CM                    1012
#define IDC_SRF08_LIGHT                 1013
#define IDC_MSG                         1014
#define IDC_SRF08_ADDR                  1015
#define IDC_SRF08_VER                   1016
#define IDC_USB_I2C_VER                 1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
