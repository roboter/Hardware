//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by usb_i2c_io.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_USB_I2C_IO_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_COM1                        1000
#define IDC_COM2                        1001
#define IDC_COM3                        1002
#define IDC_COM4                        1003
#define IDC_COM5                        1004
#define IDC_COM6                        1005
#define IDC_COM7                        1006
#define IDC_COM8                        1007
#define IDC_VER                         1008
#define IDC_H0                          1009
#define IDC_H2                          1011
#define IDC_H3                          1012
#define IDC_L0                          1013
#define IDC_L2                          1015
#define IDC_L3                          1016
#define IDC_INP0                        1017
#define IDC_INP1                        1018
#define IDC_INP2                        1019
#define IDC_INP3                        1020
#define IDC_AN1                         1022
#define IDC_AN2                         1023
#define IDC_AN3                         1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
