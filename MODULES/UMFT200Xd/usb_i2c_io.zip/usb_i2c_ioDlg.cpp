// usb_i2c_ioDlg.cpp : implementation file
//

#include "stdafx.h"
#include "usb_i2c_io.h"
#include "usb_i2c_ioDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define I2CD_CMD	0x53		// direct I2C control command
#define I2C_CMD		0x55		// registered I2C control command
#define USBI2C_CMD	0x5a		// Module command 

enum cmds { nop=0, VERSION, NEW_ADDRESS, BATTERY,
			SCAN1, SCAN2, SCAN3, SCAN4, SCAN6, SCAN8, SCAN12, SCAN16,
			SETPINS=0x10, GETPINS, GETAD,
};

enum state { Done=0, Off, On };

HANDLE hCom;
int Addr=0;
BYTE CommPort=0;
BYTE Set0=On, Set2=On, Set3=On;

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUsb_i2c_ioDlg dialog

CUsb_i2c_ioDlg::CUsb_i2c_ioDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUsb_i2c_ioDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUsb_i2c_ioDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CUsb_i2c_ioDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUsb_i2c_ioDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CUsb_i2c_ioDlg, CDialog)
	//{{AFX_MSG_MAP(CUsb_i2c_ioDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_COM1, OnCom1)
	ON_BN_CLICKED(IDC_COM2, OnCom2)
	ON_BN_CLICKED(IDC_COM3, OnCom3)
	ON_BN_CLICKED(IDC_COM4, OnCom4)
	ON_BN_CLICKED(IDC_COM5, OnCom5)
	ON_BN_CLICKED(IDC_COM6, OnCom6)
	ON_BN_CLICKED(IDC_COM7, OnCom7)
	ON_BN_CLICKED(IDC_COM8, OnCom8)
	ON_BN_CLICKED(IDC_H0, OnH0)
	ON_BN_CLICKED(IDC_H2, OnH2)
	ON_BN_CLICKED(IDC_H3, OnH3)
	ON_BN_CLICKED(IDC_L0, OnL0)
	ON_BN_CLICKED(IDC_L2, OnL2)
	ON_BN_CLICKED(IDC_L3, OnL3)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUsb_i2c_ioDlg message handlers

BOOL CUsb_i2c_ioDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	CWinApp* App = AfxGetApp( ); 
   	CommPort = App->GetProfileInt("SETTINGS","COMPORT",0);
	switch(CommPort) {
		case 1:	SetupCommPort("COM1");
				((CButton*)GetDlgItem(IDC_COM1))->SetCheck(1);
				break;
		case 2:	SetupCommPort("COM2");
				((CButton*)GetDlgItem(IDC_COM2))->SetCheck(1);
				break;
		case 3:	SetupCommPort("COM3");
				((CButton*)GetDlgItem(IDC_COM3))->SetCheck(1);
				break;
		case 4:	SetupCommPort("COM4");
				((CButton*)GetDlgItem(IDC_COM4))->SetCheck(1);
				break;
		case 5:	SetupCommPort("COM5");
				((CButton*)GetDlgItem(IDC_COM5))->SetCheck(1);
				break;
		case 6:	SetupCommPort("COM6");
				((CButton*)GetDlgItem(IDC_COM6))->SetCheck(1);
				break;
		case 7:	SetupCommPort("COM7");
				((CButton*)GetDlgItem(IDC_COM7))->SetCheck(1);
				break;
		case 8:	SetupCommPort("COM8");
				((CButton*)GetDlgItem(IDC_COM8))->SetCheck(1);
				break;
		default: ((CButton*)GetDlgItem(IDC_COM1))->SetCheck(0);
	}
	((CButton*)GetDlgItem(IDC_H0))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_H2))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_H3))->SetCheck(1);

	SetTimer(1, 100, 0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CUsb_i2c_ioDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CUsb_i2c_ioDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CUsb_i2c_ioDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CUsb_i2c_ioDlg::SetupCommPort( LPCTSTR comport)
{
	DCB dcb;
	COMMTIMEOUTS ct;

	CloseHandle(hCom);
	hCom = CreateFile( comport, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, 0, 0);
	GetCommState(hCom, &dcb);
	dcb.BaudRate = CBR_19200;
	dcb.fParity = FALSE;
	dcb.fOutxCtsFlow = FALSE;
	dcb.fOutxDsrFlow = FALSE;
	dcb.fDtrControl = DTR_CONTROL_DISABLE;
	dcb.fDsrSensitivity = FALSE;
	dcb.fOutX = FALSE;
	dcb.fInX = FALSE;
	dcb.fRtsControl = RTS_CONTROL_DISABLE;
	dcb.fAbortOnError = FALSE;
	dcb.ByteSize = 8;
	dcb.Parity = NOPARITY;
	dcb.StopBits = TWOSTOPBITS;
	SetCommState(hCom, &dcb);
  
	GetCommTimeouts(hCom, &ct);
	ct.ReadIntervalTimeout = 500;
    ct.ReadTotalTimeoutMultiplier =500; 
    ct.ReadTotalTimeoutConstant = 500; 
	SetCommTimeouts(hCom, &ct);

	SetCommMask(hCom, EV_RXCHAR);
}

void CUsb_i2c_ioDlg::OnCom1() 
{
	ClrChk();
	((CButton*)GetDlgItem(IDC_COM1))->SetCheck(1);
	CommPort = 1;	
	SetupCommPort("COM1");
   	CWinApp* App = AfxGetApp( ); 
   	App->WriteProfileInt("SETTINGS","COMPORT",CommPort);
}

void CUsb_i2c_ioDlg::OnCom2() 
{
	ClrChk();
	((CButton*)GetDlgItem(IDC_COM2))->SetCheck(1);
	CommPort = 2;	
	SetupCommPort("COM2");
   	CWinApp* App = AfxGetApp( ); 
   	App->WriteProfileInt("SETTINGS","COMPORT",CommPort);
}

void CUsb_i2c_ioDlg::OnCom3() 
{
	ClrChk();
	((CButton*)GetDlgItem(IDC_COM3))->SetCheck(1);
	CommPort = 3;	
	SetupCommPort("COM3");
   	CWinApp* App = AfxGetApp( ); 
   	App->WriteProfileInt("SETTINGS","COMPORT",CommPort);
}

void CUsb_i2c_ioDlg::OnCom4() 
{
	ClrChk();
	((CButton*)GetDlgItem(IDC_COM4))->SetCheck(1);
	CommPort = 4;	
	SetupCommPort("COM4");
   	CWinApp* App = AfxGetApp( ); 
   	App->WriteProfileInt("SETTINGS","COMPORT",CommPort);
}

void CUsb_i2c_ioDlg::OnCom5() 
{
	ClrChk();
	((CButton*)GetDlgItem(IDC_COM5))->SetCheck(1);
	CommPort = 5;	
	SetupCommPort("COM5");
   	CWinApp* App = AfxGetApp( ); 
   	App->WriteProfileInt("SETTINGS","COMPORT",CommPort);
}

void CUsb_i2c_ioDlg::OnCom6() 
{
	ClrChk();
	((CButton*)GetDlgItem(IDC_COM6))->SetCheck(1);
	CommPort = 6;	
	SetupCommPort("COM6");
   	CWinApp* App = AfxGetApp( ); 
   	App->WriteProfileInt("SETTINGS","COMPORT",CommPort);
}

void CUsb_i2c_ioDlg::OnCom7() 
{
	ClrChk();
	((CButton*)GetDlgItem(IDC_COM7))->SetCheck(1);
	CommPort = 7;	
	SetupCommPort("COM7");
   	CWinApp* App = AfxGetApp( ); 
   	App->WriteProfileInt("SETTINGS","COMPORT",CommPort);
}

void CUsb_i2c_ioDlg::OnCom8() 
{
	ClrChk();
	((CButton*)GetDlgItem(IDC_COM8))->SetCheck(1);
	CommPort = 8;	
	SetupCommPort("COM8");
   	CWinApp* App = AfxGetApp( ); 
   	App->WriteProfileInt("SETTINGS","COMPORT",CommPort);
}

void CUsb_i2c_ioDlg::ClrChk()
{
	((CButton*)GetDlgItem(IDC_COM1))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_COM2))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_COM3))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_COM4))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_COM5))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_COM6))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_COM7))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_COM8))->SetCheck(0);
}

void CUsb_i2c_ioDlg::OnH0() 
{
	((CButton*)GetDlgItem(IDC_H0))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_L0))->SetCheck(0);
	Set0 = On;
}

void CUsb_i2c_ioDlg::OnH2() 
{
	((CButton*)GetDlgItem(IDC_H2))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_L2))->SetCheck(0);
	Set2 = On;
}

void CUsb_i2c_ioDlg::OnH3() 
{
	((CButton*)GetDlgItem(IDC_H3))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_L3))->SetCheck(0);
	Set3 = On;
}

void CUsb_i2c_ioDlg::OnL0() 
{
	((CButton*)GetDlgItem(IDC_H0))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_L0))->SetCheck(1);
	Set0 = Off;
}

void CUsb_i2c_ioDlg::OnL2() 
{
	((CButton*)GetDlgItem(IDC_H2))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_L2))->SetCheck(1);
	Set2 = Off;
}

void CUsb_i2c_ioDlg::OnL3() 
{
	((CButton*)GetDlgItem(IDC_H3))->SetCheck(0);
	((CButton*)GetDlgItem(IDC_L3))->SetCheck(1);
	Set3 = Off;
}

void CUsb_i2c_ioDlg::OnTimer(UINT nIDEvent) 
{
CString s;
DWORD n;
static int ver;
BYTE sbuf[100];

	if(CommPort==0) {
		SetDlgItemText( IDC_VER, "Set Com Port" );
	}	
	else if(ver==0) {
		sbuf[0] = USBI2C_CMD;			// send nodule command			
		sbuf[1] = VERSION;				// send read version command
		sbuf[2] = 0x00;
		sbuf[3] = 0x00;
	    WriteFile(hCom, &sbuf, 4, &n, NULL);
		ReadFile(hCom, &sbuf, 1, &n, NULL);
		if(sbuf[0]>20) SetDlgItemText( IDC_VER, " No USB-I2C Module Found"  );
		else {
			s.Format("  Firmware Ver %i", sbuf[0]);
			SetDlgItemText( IDC_VER, s );
			ver = sbuf[0];
		}
	}
	else {
		sbuf[0] = USBI2C_CMD;			// send nodule command
		sbuf[1] = SETPINS;				// Setpins command
		if(Set0 || Set2 || Set3) {
			sbuf[2]=0;
			if(Set0==On) sbuf[2]=1;
			if(Set2==On) sbuf[2]|=4;
			if(Set3==On) sbuf[2]|=8;
		}
		else {
			sbuf[1] = GETPINS;			// getpins command
			sbuf[2] = 0x00;
		}
		sbuf[3] = 0x00;
	    WriteFile(hCom, &sbuf, 4, &n, NULL);

		ReadFile(hCom, &sbuf, 1, &n, NULL);
		if(sbuf[0]&1) SetDlgItemText( IDC_INP0, "H" ); else SetDlgItemText( IDC_INP0, "L" );
		if(sbuf[0]&2) SetDlgItemText( IDC_INP1, "H" ); else SetDlgItemText( IDC_INP1, "L" );
		if(sbuf[0]&4) SetDlgItemText( IDC_INP2, "H" ); else SetDlgItemText( IDC_INP2, "L" );
		if(sbuf[0]&8) SetDlgItemText( IDC_INP3, "H" ); else SetDlgItemText( IDC_INP3, "L" );

		sbuf[0] = USBI2C_CMD;			// send nodule command
		sbuf[1] = GETAD;				// Setpins command
		sbuf[2] = 0x00;
		sbuf[3] = 0x00;
	    WriteFile(hCom, &sbuf, 4, &n, NULL);
		ReadFile(hCom, &sbuf, 4, &n, NULL);
		n = (sbuf[0]<<8) + (sbuf[1]&255);
		s.Format("%04X", n);
		SetDlgItemText( IDC_AN2, s );
		n = (sbuf[2]<<8) + (sbuf[3]&255);
		s.Format("%04X", n);
		SetDlgItemText( IDC_AN3, s );
	}
	
	CDialog::OnTimer(nIDEvent);
}
